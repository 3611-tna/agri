import streamlit as st
import pandas as pd
import io
from google import genai
from google.genai.errors import APIError

# ==============================
# ⚙️ CONFIG PAGE
# ==============================
st.set_page_config(
    page_title="AgriAnalyze Pro - Phân Tích Khách Hàng Agribank",
    layout="wide"
)

# ==============================
# 🎨 HEADER
# ==============================
st.markdown("""
<div style='background:linear-gradient(90deg,#AE1C3F,#c92b4f);padding:1.2rem 2rem;border-radius:12px;margin-bottom:1.5rem;box-shadow:0 4px 10px rgba(0,0,0,0.15);'>
<h1 style='color:white;text-align:center;margin:0;'>AGRIANALYZE PRO – HỆ THỐNG PHÂN TÍCH KHÁCH HÀNG</h1>
<p style='color:#ffe4e4;text-align:center;font-size:0.95rem;margin-top:0.5rem;'>Phân tích chuyên sâu đa chiều – Dành riêng cho đội ngũ Agribank</p>
</div>
""", unsafe_allow_html=True)

# ==============================
# 🔑 API Key
# ==============================
with st.sidebar:
    st.header("🔑 Cấu hình API Key Gemini")
    api_key = st.text_input("Nhập API Key:", type="password")
    st.caption("API Key không lưu lại và chỉ dùng trong phiên hoạt động này.")

# ==============================
# 📤 Upload dữ liệu
# ==============================
st.header("📁 Bước 1. Tải file dữ liệu khách hàng Agribank")
uploaded_file = st.file_uploader("Tải file Excel (sheet: KhachHang)", type=["xlsx"])

if uploaded_file:
    df = pd.read_excel(uploaded_file, sheet_name="KhachHang")
    st.success(f"✅ Đã tải thành công {len(df)} bản ghi khách hàng.")

    with st.expander("👀 Xem trước dữ liệu"):
        st.dataframe(df.head())

    # ==============================
    # 🎯 Chọn khách hàng cần phân tích
    # ==============================
    st.header("🎯 Bước 2. Chọn khách hàng cần phân tích")
    name_filter = st.text_input("🔍 Tìm theo tên khách hàng:")
    filtered_df = df[df['Họ tên'].str.contains(name_filter, case=False, na=False)] if name_filter else df

    selected_names = st.multiselect(
        "Chọn khách hàng cần phân tích (1 hoặc nhiều người):",
        filtered_df['Họ tên'].tolist()
    )

    if selected_names:
        selected_df = df[df['Họ tên'].isin(selected_names)]

        # ==============================
        # ⚙️ Cấu hình phân tích
        # ==============================
        st.header("⚙️ Bước 3. Cấu hình phân tích chuyên sâu")

        depth = st.radio("Mức độ phân tích", ["Cơ bản", "Tiêu chuẩn", "Chuyên sâu"], index=2)
        focus_areas = st.multiselect(
            "Khía cạnh muốn tập trung phân tích:",
            [
                "Tài chính & Thu nhập", "Tôn giáo & Chính trị",
                "Sở thích & Hành vi tiêu dùng", "Tính cách & Lối sống",
                "Độ tuổi & Giai đoạn cuộc sống", "Cung hoàng đạo & Tâm lý",
                "Định hướng nghề nghiệp & Phát triển",
                "Rủi ro tín dụng & Khả năng tiết kiệm",
                "Đề xuất sản phẩm phù hợp"
            ],
            default=["Tài chính & Thu nhập", "Sở thích & Hành vi tiêu dùng", "Rủi ro tín dụng & Khả năng tiết kiệm"]
        )

        # ==============================
        # 🤖 Hàm phân tích bằng Gemini
        # ==============================
        def analyze_customers(df_customers):
            prompt = f"""
            Bạn là chuyên gia nghiên cứu hành vi & tư vấn khách hàng cao cấp của Agribank.
            Hãy phân tích dữ liệu khách hàng dưới đây theo phong cách báo cáo chuyên sâu:
            
            Mức độ phân tích: {depth}
            Các khía cạnh cần phân tích: {", ".join(focus_areas)}

            DỮ LIỆU KHÁCH HÀNG:
            {df_customers.to_markdown(index=False)}

            Hãy trình bày theo cấu trúc:
            1️⃣ **Tổng quan nhân khẩu học & hồ sơ** (giới tính, độ tuổi, khu vực, nghề nghiệp, học vấn)
            2️⃣ **Tài chính – Thu nhập – Tiêu dùng** (mức thu nhập, thói quen chi tiêu, xu hướng tiết kiệm)
            3️⃣ **Sở thích, tính cách, cung hoàng đạo, phong cách sống** (phân tích theo hành vi và sở thích)
            4️⃣ **Tôn giáo, quan điểm chính trị (nếu có)** – chỉ dùng để hiểu hành vi, không phán xét
            5️⃣ **Đánh giá rủi ro – Mức độ tin cậy & tín dụng**
            6️⃣ **Gợi ý sản phẩm & chiến lược tiếp cận cá nhân hóa**
            7️⃣ **Tổng kết: Nhận định toàn diện & khuyến nghị**
            """

            try:
                client = genai.Client(api_key=api_key)
                response = client.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=prompt
                )
                return response.text
            except APIError as e:
                return f"Lỗi API Gemini: {e}"
            except Exception as e:
                return f"Lỗi khác: {e}"

        # ==============================
        # 🚀 Phân tích
        # ==============================
        if st.button("🚀 Tiến hành phân tích chuyên sâu"):
            if not api_key:
                st.error("❌ Vui lòng nhập API Key trước khi chạy.")
            else:
                with st.spinner("🤖 Đang phân tích, vui lòng chờ..."):
                    result = analyze_customers(selected_df)

                st.subheader("📋 Kết quả phân tích chuyên sâu")
                st.markdown(result)

                # Tải xuống kết quả
                buffer = io.BytesIO()
                selected_df.to_excel(buffer, index=False, sheet_name="KhachHangPhanTich")
                st.download_button(
                    label="📊 Xuất dữ liệu khách hàng (.xlsx)",
                    data=buffer.getvalue(),
                    file_name="AgriAnalyze_KetQua.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )

                txt_file = io.BytesIO(result.encode('utf-8'))
                st.download_button("📝 Tải báo cáo phân tích (.txt)", data=txt_file, file_name="BaoCao_AgriAnalyze.txt")

else:
    st.info("⬆️ Hãy tải lên file Excel để bắt đầu quá trình phân tích.")

# ==============================
# ⚓ FOOTER
# ==============================
st.markdown("""
<hr style='border:1px solid #ccc;margin-top:3rem;'>
<div style='text-align:center;color:gray;font-size:0.9rem;'>
© 2025 Agribank Training & Development Team — Ứng dụng <strong>AgriAnalyze Pro</strong><br>
Phát triển bởi bộ phận CNTT Agribank | Màu chủ đạo: #AE1C3F<br>
<em>Phiên bản nội bộ dành cho nghiên cứu & đào tạo – Không sử dụng ngoài hệ thống Agribank.</em>
</div>
""", unsafe_allow_html=True)
